package com.example.basketballscore

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView

class ResultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)
        victoria()
    }
    fun victoria(){
        val objectIntent: Intent =intent
        var marcadorVisitante = objectIntent.getStringExtra("marcadorVisitante")
        var marcadorLocal = objectIntent.getStringExtra("marcadorLocal")

        marcadorVisitante = marcadorVisitante.toString()
        marcadorLocal = marcadorLocal.toString()

        var Resultado=findViewById<View>(R.id.textView7) as TextView
        var Marcador=findViewById<View>(R.id.textView8)as TextView
        Marcador.setText(marcadorLocal + "-" + marcadorVisitante)

        if(marcadorVisitante.toInt() > marcadorLocal.toInt()){
            Resultado.setText("El ganador fue el visitante")
        }else if(marcadorVisitante.toInt() < marcadorLocal.toInt()){
            Resultado.setText("El ganador fue el local")
        }else{
            Resultado.setText("Es un empate")
        }

    }
}