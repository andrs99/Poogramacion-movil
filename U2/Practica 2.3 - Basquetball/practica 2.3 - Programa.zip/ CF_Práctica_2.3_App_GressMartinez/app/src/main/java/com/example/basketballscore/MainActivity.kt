package com.example.basketballscore

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    var marcadorVisitante: Int = 0
    var marcadorLocal: Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        canasta()
    }
    fun canasta(){
        var Visitante=findViewById<View>(R.id.textView4) as TextView
        var Local=findViewById<View>(R.id.textView2) as TextView

        var btnSumar1V=findViewById<View>(R.id.button2) as Button
        btnSumar1V.setOnClickListener(){
            marcadorVisitante++
            Visitante.setText(marcadorVisitante.toString())
        }
        var btnSumar2V=findViewById<View>(R.id.button5) as Button
        btnSumar2V.setOnClickListener(){
            marcadorVisitante=marcadorVisitante+2
            Visitante.setText(marcadorVisitante.toString())
        }
        var btnRestar1V=findViewById<View>(R.id.button7) as Button
        btnRestar1V.setOnClickListener(){
            if(marcadorVisitante!=0) {
                marcadorVisitante--
                Visitante.setText(marcadorVisitante.toString())
            }
        }


        var btnSumar1L=findViewById<View>(R.id.button6) as Button
        btnSumar1L.setOnClickListener(){
            marcadorLocal++
            Local.setText(marcadorLocal.toString())
        }
        var btnSumar2L=findViewById<View>(R.id.button3) as Button
        btnSumar2L.setOnClickListener(){
            marcadorLocal=marcadorLocal+2
            Local.setText(marcadorLocal.toString())
        }
        var btnRestar1L=findViewById<View>(R.id.button8) as Button
        btnRestar1L.setOnClickListener(){
            if(marcadorLocal!=0) {
                marcadorLocal--
                Local.setText(marcadorLocal.toString())
            }
        }

        var btnReset=findViewById<View>(R.id.button4) as Button
        btnReset.setOnClickListener(){
            marcadorVisitante = 0
            marcadorLocal = 0
            var Local = findViewById<View>(R.id.textView4) as TextView
            var Visitante=findViewById<View>(R.id.textView2) as TextView
            Local.setText(marcadorLocal.toString())
            Visitante.setText(marcadorVisitante.toString())
        }
        var btnResult=findViewById<View>(R.id.button) as Button
        btnResult.setOnClickListener(){
            val intent = Intent(this, ResultActivity::class.java)
            intent.putExtra("marcadorVisitante" , marcadorVisitante.toString())
            intent.putExtra("marcadorLocal" , marcadorLocal.toString())
            startActivity(intent)
        }


    }
}
