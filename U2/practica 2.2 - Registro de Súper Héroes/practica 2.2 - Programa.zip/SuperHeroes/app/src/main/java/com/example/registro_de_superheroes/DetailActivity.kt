package com.example.registro_de_superheroes

import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.registro_de_superheroes.databinding.ActivityDetailBinding
import com.example.registro_de_superheroes.databinding.ActivityMainBinding

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bundle = intent.extras!!
        val superhero = bundle.getParcelable<Superhero>("Superhero")!!
        val bitmap = bundle.getParcelable<Bitmap>("BitmapKey")

        binding.imageView.setImageBitmap(bitmap)
        binding.superhero = superhero

    }
}