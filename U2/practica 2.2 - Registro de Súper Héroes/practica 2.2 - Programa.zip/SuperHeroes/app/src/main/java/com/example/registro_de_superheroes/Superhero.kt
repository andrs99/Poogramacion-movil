package com.example.registro_de_superheroes

import android.os.Parcel
import android.os.Parcelable


class Superhero (val name: String, val alterEgo: String, val bio: String, val power: Float) : Parcelable {
    constructor(parcel: Parcel) : this(
            parcel.readString().toString(),
            parcel.readString().toString(),
            parcel.readString().toString(),
            parcel.readFloat()) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(name)
        parcel.writeString(alterEgo)
        parcel.writeString(bio)
        parcel.writeFloat(power)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Superhero> {
        override fun createFromParcel(parcel: Parcel): Superhero {
            return Superhero(parcel)
        }

        override fun newArray(size: Int): Array<Superhero?> {
            return arrayOfNulls(size)
        }
    }
}